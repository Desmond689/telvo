// src/services/reviewService.ts
import { addDoc, collection, getDocs, orderBy, query, serverTimestamp, where } from 'firebase/firestore';
import { db, COLLECTIONS } from '@/lib/firebase';
import type { Review } from '@/types';

export async function getReviewsForUser(userId: string): Promise<Review[]> {
  const q = query(collection(db, COLLECTIONS.REVIEWS), where('reviewedId', '==', userId), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Review));
}

export async function hasReviewedJob(jobId: string, reviewerId: string): Promise<boolean> {
  const q = query(collection(db, COLLECTIONS.REVIEWS), where('jobId', '==', jobId), where('reviewerId', '==', reviewerId));
  const snap = await getDocs(q);
  return !snap.empty;
}

export async function submitReview(input: {
  jobId: string;
  reviewerId: string;
  reviewedId: string;
  rating: number;
  comment: string;
  photos?: string[];
}) {
  if (await hasReviewedJob(input.jobId, input.reviewerId)) {
    throw new Error('You have already reviewed this job.');
  }
  await addDoc(collection(db, COLLECTIONS.REVIEWS), {
    ...input,
    photos: input.photos ?? [],
    videos: [],
    ratings: {},
    isAnonymous: false,
    isResponse: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}
