// src/contexts/AuthContext.tsx
//
// Real Firebase Authentication - no mock/demo users. Supports:
//  - Email + password
//  - Cameroon phone number + OTP (Firebase Phone Auth, invisible reCAPTCHA)
//  - Live Firestore listener on /users/{uid} so role, verification status,
//    and profile fields update in real time everywhere in the app.

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  type ConfirmationResult,
  type User as FirebaseUser,
} from 'firebase/auth';
import { doc, onSnapshot, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, COLLECTIONS } from '@/lib/firebase';
import type { TelvoUser, UserType } from '@/types';

interface AuthContextValue {
  firebaseUser: FirebaseUser | null;
  profile: TelvoUser | null;
  loading: boolean;
  error: string | null;
  signUpWithEmail: (email: string, password: string, fullName: string, userType: UserType) => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  startPhoneSignIn: (phoneNumber: string, recaptchaContainerId: string) => Promise<ConfirmationResult>;
  confirmPhoneOtp: (confirmation: ConfirmationResult, otp: string, fullName?: string, userType?: UserType) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// Cameroon phone numbers: +237 6XXXXXXXX (9 digits after country code)
export function normalizeCameroonPhone(input: string): string {
  const digits = input.replace(/\D/g, '');
  if (digits.startsWith('237')) return `+${digits}`;
  if (digits.startsWith('6') && digits.length === 9) return `+237${digits}`;
  return `+${digits}`;
}

async function ensureUserDoc(uid: string, data: Partial<TelvoUser>) {
  const ref = doc(db, COLLECTIONS.USERS, uid);
  await setDoc(
    ref,
    {
      id: uid,
      isVerified: false,
      isPhoneVerified: false,
      isEmailVerified: false,
      isIdVerified: false,
      isSelfieVerified: false,
      trustedContacts: [],
      isOnline: true,
      rating: 0,
      jobsCompleted: 0,
      responseRate: 0,
      responseTime: 0,
      favorites: [],
      blockedUsers: [],
      isSuspended: false,
      createdAt: serverTimestamp(),
      lastActive: serverTimestamp(),
      ...data,
    },
    { merge: true }
  );
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<TelvoUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      if (!user) {
        setProfile(null);
        setLoading(false);
      }
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (!firebaseUser) return;
    const ref = doc(db, COLLECTIONS.USERS, firebaseUser.uid);
    const unsub = onSnapshot(
      ref,
      (snap) => {
        setProfile(snap.exists() ? ({ id: snap.id, ...snap.data() } as TelvoUser) : null);
        setLoading(false);
      },
      (err) => {
        console.error('[TELVO] Failed to load user profile:', err);
        setError('We could not load your profile. Please refresh the page.');
        setLoading(false);
      }
    );
    return unsub;
  }, [firebaseUser]);

  const clearError = useCallback(() => setError(null), []);

  const signUpWithEmail = useCallback(async (email: string, password: string, fullName: string, userType: UserType) => {
    setError(null);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await ensureUserDoc(cred.user.uid, { email, fullName, userType, mode: userType === 'admin' ? undefined : userType });
    } catch (e: any) {
      setError(mapAuthError(e?.code));
      throw e;
    }
  }, []);

  const signInWithEmail = useCallback(async (email: string, password: string) => {
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (e: any) {
      setError(mapAuthError(e?.code));
      throw e;
    }
  }, []);

  const startPhoneSignIn = useCallback(async (phoneNumber: string, recaptchaContainerId: string) => {
    setError(null);
    try {
      const verifier = new RecaptchaVerifier(auth, recaptchaContainerId, { size: 'invisible' });
      const formatted = normalizeCameroonPhone(phoneNumber);
      return await signInWithPhoneNumber(auth, formatted, verifier);
    } catch (e: any) {
      setError(mapAuthError(e?.code));
      throw e;
    }
  }, []);

  const confirmPhoneOtp = useCallback(
    async (confirmation: ConfirmationResult, otp: string, fullName?: string, userType?: UserType) => {
      setError(null);
      try {
        const cred = await confirmation.confirm(otp);
        await ensureUserDoc(cred.user.uid, {
          phoneNumber: cred.user.phoneNumber ?? undefined,
          isPhoneVerified: true,
          ...(fullName ? { fullName } : {}),
          ...(userType ? { userType, mode: userType === 'admin' ? undefined : userType } : {}),
        });
      } catch (e: any) {
        setError(mapAuthError(e?.code));
        throw e;
      }
    },
    []
  );

  const resetPassword = useCallback(async (email: string) => {
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (e: any) {
      setError(mapAuthError(e?.code));
      throw e;
    }
  }, []);

  const signOut = useCallback(async () => {
    await firebaseSignOut(auth);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        loading,
        error,
        signUpWithEmail,
        signInWithEmail,
        startPhoneSignIn,
        confirmPhoneOtp,
        resetPassword,
        signOut,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

function mapAuthError(code?: string): string {
  switch (code) {
    case 'auth/email-already-in-use':
      return 'An account already exists with this email.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/weak-password':
      return 'Your password should be at least 6 characters.';
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please wait a moment and try again.';
    case 'auth/invalid-phone-number':
      return 'Please enter a valid Cameroon phone number.';
    case 'auth/invalid-verification-code':
      return 'That code is incorrect. Please check and try again.';
    case 'auth/code-expired':
      return 'That code has expired. Please request a new one.';
    default:
      return 'Something went wrong. Please try again.';
  }
}
