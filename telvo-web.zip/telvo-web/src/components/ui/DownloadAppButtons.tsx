import { Apple, PlayCircle } from 'lucide-react';
import clsx from 'clsx';

// Store URLs are read from env so they can be updated the moment the app
// is published, without a code change. Falls back to a disabled
// "Coming soon" state until real links are set.
const APP_STORE_URL = import.meta.env.VITE_APP_STORE_URL as string | undefined;
const PLAY_STORE_URL = import.meta.env.VITE_PLAY_STORE_URL as string | undefined;

export function DownloadAppButtons({ variant = 'dark', size = 'md' }: { variant?: 'dark' | 'light'; size?: 'sm' | 'md' }) {
  const base = clsx(
    'inline-flex items-center gap-2 rounded-xl font-semibold transition-colors',
    size === 'sm' ? 'h-10 px-3.5 text-xs' : 'h-12 px-5 text-sm',
    variant === 'dark' ? 'bg-ink-900 text-white hover:bg-ink-800' : 'bg-white text-ink-900 hover:bg-ink-50 border border-ink-200'
  );

  return (
    <div className="flex flex-col sm:flex-row items-center gap-3">
      <a
        href={APP_STORE_URL || '#'}
        target={APP_STORE_URL ? '_blank' : undefined}
        rel="noreferrer"
        aria-disabled={!APP_STORE_URL}
        className={clsx(base, !APP_STORE_URL && 'opacity-60 cursor-not-allowed')}
        onClick={(e) => !APP_STORE_URL && e.preventDefault()}
      >
        <Apple size={size === 'sm' ? 16 : 20} />
        <span className="text-left leading-tight">
          <span className="block text-[10px] opacity-70">{APP_STORE_URL ? 'Download on the' : 'Coming soon to'}</span>
          <span className="block">App Store</span>
        </span>
      </a>
      <a
        href={PLAY_STORE_URL || '#'}
        target={PLAY_STORE_URL ? '_blank' : undefined}
        rel="noreferrer"
        aria-disabled={!PLAY_STORE_URL}
        className={clsx(base, !PLAY_STORE_URL && 'opacity-60 cursor-not-allowed')}
        onClick={(e) => !PLAY_STORE_URL && e.preventDefault()}
      >
        <PlayCircle size={size === 'sm' ? 16 : 20} />
        <span className="text-left leading-tight">
          <span className="block text-[10px] opacity-70">{PLAY_STORE_URL ? 'Get it on' : 'Coming soon to'}</span>
          <span className="block">Google Play</span>
        </span>
      </a>
    </div>
  );
}
