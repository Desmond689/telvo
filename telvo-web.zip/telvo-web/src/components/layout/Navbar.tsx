import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Menu, X, Bell, ChevronDown, Heart, Download } from 'lucide-react';
import { Logo } from './Logo';
import { Button } from '../ui/Button';
import { useAuth } from '@/contexts/AuthContext';
import { dashboardHomeFor } from '@/utils/roles';

const navLinks = [
  { to: '/find-services', label: 'Find Services' },
  { to: '/professionals', label: 'Professionals' },
  { to: '/businesses', label: 'Businesses' },
  { to: '/how-it-works', label: 'How It Works' },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const { firebaseUser, profile, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-ink-100">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Logo />
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive ? 'text-brand-600 bg-brand-50' : 'text-ink-600 hover:text-ink-900 hover:bg-ink-50'
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </div>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Link to="/donate" className="px-3 py-2 rounded-lg text-sm font-medium text-ink-600 hover:text-brand-600 hover:bg-brand-50 flex items-center gap-1.5">
            <Heart size={15} /> Support Us
          </Link>
          <Link to="/download" className="px-3 py-2 rounded-lg text-sm font-medium text-ink-600 hover:text-ink-900 hover:bg-ink-50 flex items-center gap-1.5">
            <Download size={15} /> Get the App
          </Link>
          {firebaseUser && profile ? (
            <>
              <button
                className="relative p-2 rounded-lg hover:bg-ink-50 text-ink-500"
                onClick={() => navigate(`${dashboardHomeFor(profile.userType)}/notifications`)}
                aria-label="Notifications"
              >
                <Bell size={19} />
              </button>
              <button
                onClick={() => navigate(dashboardHomeFor(profile.userType))}
                className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-full border border-ink-200 hover:border-brand-500 transition-colors"
              >
                <span className="w-7 h-7 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-xs font-bold overflow-hidden">
                  {profile.profilePhoto ? (
                    <img src={profile.profilePhoto} alt="" className="w-full h-full object-cover" />
                  ) : (
                    profile.fullName?.[0]?.toUpperCase() || 'U'
                  )}
                </span>
                <ChevronDown size={14} className="text-ink-400" />
              </button>
              <Button variant="ghost" size="sm" onClick={() => signOut().then(() => navigate('/'))}>
                Sign out
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate('/login')}>
                Log in
              </Button>
              <Button size="sm" onClick={() => navigate('/register')}>
                Join TELVO
              </Button>
            </>
          )}
        </div>

        <button className="md:hidden p-2 text-ink-700" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden border-t border-ink-100 px-4 py-4 space-y-1 animate-slide-up bg-white">
          {navLinks.map((l) => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="block px-3 py-2.5 rounded-lg text-sm font-medium text-ink-700 hover:bg-ink-50">
              {l.label}
            </Link>
          ))}
          <Link to="/donate" onClick={() => setOpen(false)} className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-brand-700 bg-brand-50">
            <Heart size={16} /> Support Us
          </Link>
          <Link to="/download" onClick={() => setOpen(false)} className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-ink-700 hover:bg-ink-50">
            <Download size={16} /> Get the App
          </Link>
          <div className="pt-3 mt-3 border-t border-ink-100 flex flex-col gap-2">
            {firebaseUser && profile ? (
              <>
                <Button variant="outline" onClick={() => navigate(dashboardHomeFor(profile.userType))}>
                  Go to dashboard
                </Button>
                <Button variant="ghost" onClick={() => signOut().then(() => navigate('/'))}>
                  Sign out
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => navigate('/login')}>
                  Log in
                </Button>
                <Button onClick={() => navigate('/register')}>Join TELVO</Button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
