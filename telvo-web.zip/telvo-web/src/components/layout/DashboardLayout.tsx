import { type ReactNode, useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Menu, X, Bell, LogOut, type LucideIcon } from 'lucide-react';
import { Logo } from './Logo';
import { useAuth } from '@/contexts/AuthContext';
import { VerifiedBadge } from '../ui/VerifiedBadge';

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  end?: boolean;
}

export function DashboardLayout({ navItems, roleLabel }: { navItems: NavItem[]; roleLabel: string }) {
  const [open, setOpen] = useState(false);
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  const Sidebar = (
    <div className="flex flex-col h-full">
      <div className="px-5 py-5 border-b border-ink-100">
        <Logo />
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive ? 'bg-brand-50 text-brand-700' : 'text-ink-600 hover:bg-ink-50'
              }`
            }
          >
            <item.icon size={18} />
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="p-3 border-t border-ink-100">
        <div className="flex items-center gap-3 px-2 py-2">
          <span className="w-9 h-9 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-sm font-bold overflow-hidden flex-shrink-0">
            {profile?.profilePhoto ? (
              <img src={profile.profilePhoto} alt="" className="w-full h-full object-cover" />
            ) : (
              profile?.fullName?.[0]?.toUpperCase() || 'U'
            )}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-ink-900 truncate flex items-center gap-1">
              {profile?.fullName || 'User'} {profile?.isVerified && <VerifiedBadge size={13} />}
            </p>
            <p className="text-xs text-ink-400">{roleLabel}</p>
          </div>
          <button
            onClick={() => signOut().then(() => navigate('/'))}
            className="p-2 rounded-lg hover:bg-ink-100 text-ink-400"
            aria-label="Sign out"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-ink-50 flex">
      <aside className="hidden lg:block w-64 flex-shrink-0 bg-white border-r border-ink-100 sticky top-0 h-screen">{Sidebar}</aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink-900/40" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-72 bg-white animate-slide-up">{Sidebar}</div>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-ink-100 h-16 flex items-center justify-between px-4 sm:px-6">
          <button className="lg:hidden p-2 -ml-2 text-ink-700" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu size={22} />
          </button>
          <div className="hidden lg:block" />
          <div className="flex items-center gap-3">
            <Link to="notifications" className="relative p-2 rounded-lg hover:bg-ink-100 text-ink-500" aria-label="Notifications">
              <Bell size={19} />
            </Link>
            <Link to="/" className="text-sm text-ink-500 hover:text-ink-800 hidden sm:block">
              ← Back to site
            </Link>
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
